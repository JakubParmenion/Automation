﻿using System.Configuration;
using TechTalk.SpecFlow;
using UI.Automation.Features.Calculator.FunctionalElements;
using UI.Automation.Utilities;

namespace UI.Automation
{
    [Binding]
    public class DivisionCalculationSteps
    {
        CalDivisionPage calDivisionPageSection;

        [Given(@"I have entered values")]
        public void GivenIHaveEnteredValues()
        {
            calDivisionPageSection = new CalDivisionPage();
            DriverFactory.InitBrowser(ConfigurationManager.AppSettings["Driver"]);
            DriverFactory.LoadApplication(ConfigurationManager.AppSettings["URL"]);
            calDivisionPageSection.Setup(DriverFactory.Driver);
            calDivisionPageSection.EnterValues();
        }

        [Then(@"Click the Division Button")]
        public void ThenClickTheDivisionButton()
        {
            calDivisionPageSection.ClickDivisionButton();
        }

    }
}
