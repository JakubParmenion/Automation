﻿using OpenQA.Selenium;


namespace UI.Automation.Features.Calculator.FunctionalElements
{
    public class CalDivisionPage
    {
        protected IWebElement NumeratorField { get; private set; }

        protected IWebElement DenominatorField { get; private set; }

        protected IWebElement DivisionButton { get; private set; }

        public void Setup(IWebDriver driver)
        {
            NumeratorField = driver.FindElement(By.Id("Numerator"));
            DenominatorField = driver.FindElement(By.Id("Denominator"));
            DivisionButton = driver.FindElement(By.Id("Submit"));
        }

        public void EnterValues()
        {
            NumeratorField.Click();
            NumeratorField.SendKeys("50");

            DenominatorField.Click();
            DenominatorField.SendKeys("5");
        }

        public void ClickDivisionButton()
        {
            DivisionButton.Click();
        }
    }
}
